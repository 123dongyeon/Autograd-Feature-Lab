import torch

def feature_map(x):
    return torch.cat([x, x**2, x**3], dim=1)
