import torch
from load_data import load_data
from utils import feature_map

x, y = load_data()
phi = feature_map(x)

w = torch.randn(phi.size(1), 1, requires_grad=True)
lr = 0.1

for epoch in range(100):
    pred = phi @ w
    loss = ((pred - y) ** 2).mean()
    loss.backward()

    with torch.no_grad():
        w -= lr * w.grad
        w.grad.zero_()

    if epoch % 10 == 0:
        print(f"Epoch {epoch}, Loss {loss.item():.4f}")
