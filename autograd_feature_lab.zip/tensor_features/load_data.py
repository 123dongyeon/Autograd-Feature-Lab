import torch

def load_data(n=100):
    x = torch.linspace(-1, 1, n).unsqueeze(1)
    y = x ** 2 + 0.1 * torch.randn_like(x)
    return x, y
